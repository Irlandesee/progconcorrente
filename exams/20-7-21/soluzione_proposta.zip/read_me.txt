Istruzioni per Linux

cd <path del programma>
cd Server
javac *.java
cd ../Client
javac *.java
cd ../Registry
javac *.java

Nel terminale 1:
cd <path del programma>/Registry
java PRegistry &
cd ../Server
java ServerLauncher

Nel terminale 2:
java Client pippo &
java Client pluto &
java Client paperino


