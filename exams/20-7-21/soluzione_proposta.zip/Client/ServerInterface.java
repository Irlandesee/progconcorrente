
public interface ServerInterface {
	public String echo(String s);
}
