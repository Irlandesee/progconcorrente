import java.io.Serializable;
import java.net.InetAddress;

public class RemoteReference implements Serializable {
	private static final long serialVersionUID = 1L;
	InetAddress ipa;
	int port;
	RemoteReference(InetAddress a, int p){
		ipa=a;
		port=p;
	}
	public InetAddress getIpa() {
		return ipa;
	}
	public int getPort() {
		return port;
	}
}
