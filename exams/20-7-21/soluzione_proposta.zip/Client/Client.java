import java.net.InetAddress;
import java.net.UnknownHostException;

public class Client {
	RemoteReference serverRef;
	LocateReg theRegistry;
	ServerProxy theServer;
	String myId;
	Client(String id){
		myId=id;
		System.out.println("Starting client "+myId);
		try {
			theRegistry = new LocateReg(InetAddress.getByName("localhost"), 2099);
			System.out.println("client "+myId+": registry located");
			if(theRegistry != null) {
				serverRef=theRegistry.lookup("ECHO");
				System.out.println("client "+myId+": server found");
				theServer= new ServerProxy(serverRef);
				System.out.println("client "+myId+": proxy created");
			} else {
				System.err.println("client: no Registry");
				System.exit(0);
			}
		} catch (UnknownHostException e) {
			System.err.println("client: no Registry/2");
			System.exit(0);
		}
	}
	void exec() {
		String str=null;
		System.out.println("client "+myId+" in execution");
		for(int i=0; i<3; i++) {
			str="cli_"+myId+"_str_"+i;
			System.out.println("client "+myId+" sending:"+str);			
			str=theServer.echo(str);
			System.out.println("client "+myId+" received:"+str);			
		}
	}
	public static void main(String args[]) {
		if(args.length==0) {
			new Client("anonymous").exec();
		} else {
			new Client(args[0]).exec();
		}
	}
}
