import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.*;

public class ServerProxy implements ServerInterface{
	InetAddress serverAddress;
	int serverPort;
	Socket serverSock;
	ObjectInputStream obj_in_s;
	ObjectOutputStream obj_out_s;
	public ServerProxy(RemoteReference serverRef) {
		serverAddress=serverRef.getIpa();
		serverPort=serverRef.getPort();
	}

	public String echo(String s) {
		try {
			serverSock=new Socket(serverAddress, serverPort);
			obj_out_s = new ObjectOutputStream(serverSock.getOutputStream());
			obj_in_s = new ObjectInputStream(serverSock.getInputStream());
			obj_out_s.writeObject("echo");
			obj_out_s.flush();
			obj_out_s.writeObject(s);
			obj_out_s.flush();
			return (String) obj_in_s.readObject();
		} catch (IOException | ClassNotFoundException e) {
			return null;
		}
	}

}
