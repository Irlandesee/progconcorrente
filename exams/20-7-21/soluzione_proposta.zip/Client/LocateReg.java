import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.*;

public class LocateReg {
	InetAddress registryAddress;
	int registryPort;
	LocateReg(InetAddress a, int p){
		registryAddress=a;
		registryPort=p;
	}
	public RemoteReference lookup(String service) {
		Socket s;
		System.out.println("locateRegistry: lookup received for "+service);
		try {
			System.out.println("locateRegistry: connecting to "+registryAddress+" "+registryPort);
			s=new Socket(registryAddress, registryPort);
			System.out.println("locateRegistry: connected");
			ObjectOutputStream obj_out_s = new ObjectOutputStream(s.getOutputStream());
			ObjectInputStream obj_in_s = new ObjectInputStream(s.getInputStream());
			System.out.println("locateRegistry: going to lookup ");
			obj_out_s.writeObject("lookup");
			obj_out_s.flush();
			obj_out_s.writeObject(service);
			obj_out_s.flush();
			System.out.println("locateRegistry: remote reference received ");
			RemoteReference rr= (RemoteReference) obj_in_s.readObject();
			System.out.println("locateRegistry: remore reference returned ");
			return rr;
		} catch (IOException | ClassNotFoundException e) {
			System.err.println("locateRegistry: lookup failure ");
			return null;
		}
	}
	public boolean bind(String service, RemoteReference rr) {
		Socket s;
		try {
			s=new Socket(registryAddress, registryPort);
			ObjectOutputStream obj_out_s = new ObjectOutputStream(s.getOutputStream());
			ObjectInputStream obj_in_s = new ObjectInputStream(s.getInputStream());
			obj_out_s.writeObject("bind");
			obj_out_s.flush();
			obj_out_s.writeObject(service);
			obj_out_s.flush();
			obj_out_s.writeObject(rr);
			obj_out_s.flush();
			return true;
		} catch (IOException e) {
			System.err.println("locateRegistry: bind failure ");
			return false;
		}
	}
}
