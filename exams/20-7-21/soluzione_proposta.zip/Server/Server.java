
public class Server implements ServerInterface{
	Server(){
	}
	public synchronized String echo(String s) {
		return s;
	}
}
