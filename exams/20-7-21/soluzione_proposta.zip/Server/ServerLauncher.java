import java.io.IOException;
import java.net.*;

public class ServerLauncher {
	Server theServer;
	RemoteReference serverRef;
	LocateReg theRegistry;
	final int echoServerPort=3311;
	ServerSocket servToRegSock=null;
	ServerLauncher(){
		try {
			theServer=new Server();
			theRegistry = new LocateReg(InetAddress.getByName("localhost"), 2099);
			servToRegSock=new ServerSocket(echoServerPort);
			if(theRegistry != null) {
				theRegistry.bind("ECHO", new RemoteReference(InetAddress.getByName("localhost"), 
						                                     echoServerPort));
			} else {
				System.err.println("client: no Registry");
				System.exit(0);
			}
		} catch (IOException e) {
			System.err.println("no Server");
			System.exit(0);
		}
	}
	void exec() {
		Socket connectSock=null;
		while(true) {
			try {
				connectSock=servToRegSock.accept();
				new ServerSlave(connectSock, theServer).start();
			} catch (IOException e) { }
		}

	}
	public static void main(String args[]) {
		new ServerLauncher().exec();
	}
}
