import java.io.*;
import java.net.*;

public class ServerSlave extends Thread {
	ObjectInputStream obj_in_s;
	ObjectOutputStream obj_out_s;
	Socket clientSocket=null;
	Server theServer=null;
	ServerSlave(Socket s, Server serv){
			clientSocket=s;
			theServer=serv;
	}
	public void run() {
		String request=null;
		String str=null;
		try {
			obj_out_s = new ObjectOutputStream(clientSocket.getOutputStream());
			obj_in_s = new ObjectInputStream(clientSocket.getInputStream());
			request=(String)obj_in_s.readObject();
			if(request.equals("echo")) {
				str=(String)obj_in_s.readObject();
				obj_out_s.writeObject(theServer.echo(str));
				obj_out_s.flush();
			}
		} catch (IOException | ClassNotFoundException e) {
			System.err.println("Slave communication error");
		}
	}
}
