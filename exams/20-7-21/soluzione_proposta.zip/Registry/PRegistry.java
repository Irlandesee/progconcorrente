import java.io.IOException;
import java.io.*;
import java.net.*;
import java.util.Hashtable;

public class PRegistry {
	final int regPort = 2099;
	PRegistry(){
		serverList = new Hashtable<String, RemoteReference>();
	}
	Hashtable<String, RemoteReference> serverList;
	void exec() {
		ServerSocket regSock=null;
		Socket cliSock=null;
		ObjectInputStream obj_in_s;
		ObjectOutputStream obj_out_s;
		String request=null;
		String service=null;
		RemoteReference remoteRef=null;
		try {
			regSock = new ServerSocket(regPort);
		} catch (IOException e) {
			System.err.println("Registry start failed");
			System.exit(0);
		}
		System.out.println("Registry: running");
		while(true) {
			try {
				cliSock=regSock.accept();
				System.out.println("Registry: connected");
			} catch (IOException e) {
				System.err.println("Registry cannot accept connections");
				System.exit(0);
			}
			try {
				obj_out_s = new ObjectOutputStream(cliSock.getOutputStream());
				obj_in_s = new ObjectInputStream(cliSock.getInputStream());
				request=(String)obj_in_s.readObject();
				if(request.equals("lookup")) {
					System.out.println("Registry: performing lookup");
					service=(String)obj_in_s.readObject();
					obj_out_s.writeObject(serverList.get(service));
					obj_out_s.flush();
				}
				else if(request.equals("bind")) {
					System.out.println("Registry: performing bind");
					service=(String)obj_in_s.readObject();
					remoteRef=(RemoteReference)obj_in_s.readObject();
					serverList.put(service, remoteRef);
					obj_out_s.writeObject(null);
					obj_out_s.flush();
				} else {
					System.err.println("Registry: command not recognized");
				}			
			} catch (IOException | ClassNotFoundException e) {
				System.err.println("Communication problems");
				try {
					cliSock.close();
				} catch (IOException e1) {}
				continue;
			}
		}
	}
	public static void main(String args[]) {
		new PRegistry().exec();
	}
}
