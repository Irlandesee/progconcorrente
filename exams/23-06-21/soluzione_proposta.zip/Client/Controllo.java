
public class Controllo {
	boolean attendoFineAggiunta=false;
	boolean attendoFinePrelievo=false;
	Controllo(){
		attendoFineAggiunta=false;
		attendoFinePrelievo=false;
	}
	public synchronized void inizioAttesaFineAggiunta() {
		attendoFineAggiunta=true;
	}
	public synchronized void inizioAttesaFinePrelievo() {
		attendoFinePrelievo=true;
	}
	public synchronized boolean autorizzazioneAggiunta() {
		while(attendoFineAggiunta) {
			try {
				wait(2000);
				if(attendoFineAggiunta) {
					return false;
				}
			} catch (InterruptedException e) {	}
		}
		return true;
	}
	public synchronized boolean autorizzazionePrelievo() {
		while(attendoFinePrelievo) {
			try {
				wait(2000);
				if(attendoFinePrelievo) {
					return false;
				}
			} catch (InterruptedException e) {	}
		}
		return true;
	}
	public synchronized void completamentoAggiunta() {
		attendoFineAggiunta=false;
		notifyAll();
	}
	public synchronized void completamentoPrelievo() {
		attendoFinePrelievo=false;
		notifyAll();
	}
}
