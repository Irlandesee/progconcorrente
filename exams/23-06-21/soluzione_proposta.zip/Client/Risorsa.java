import java.io.Serializable;

public class Risorsa implements Serializable {
	private static final long serialVersionUID = 1L;
	String Descrizione;
	long timestamp;
	Object content;
	Risorsa(String d, Object c){
		Descrizione=d;
		content=c;
		timestamp=System.currentTimeMillis();
	}
	public String getDescrizione() {
		return Descrizione;
	}
	public void setDescrizione(String descrizione) {
		Descrizione = descrizione;
	}
	public long getTimestamp() {
		return timestamp;
	}
}
