import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Random;

public class ClientImpl extends UnicastRemoteObject implements ClientInterf{
	private static final long serialVersionUID = 1L;
	ServerInterf theServer;
	Controllo ctrl=null;
	String myName;
	protected ClientImpl(ServerInterf s, String n) throws RemoteException {
		super();
		ctrl=new Controllo();
		theServer=s;
		myName=n;
	}
	public void comunicaRisorsa(Risorsa r) throws RemoteException {
		System.out.println(myName+": ho ricevuto una risorsa");
		ctrl.completamentoPrelievo();
	}
	public void comunicaAggiunta() throws RemoteException {
		System.out.println(myName+": ho ricevuto notifica di fine aggiunta");
		ctrl.completamentoAggiunta();
	}
	void exec() {
		Random rnd= new Random();
		while(true) {
			int dado;
			dado=rnd.nextInt(13);
			if(dado==0) {
				break;
			}
			if(dado<7) {
				// faccio un'aggiunta
				System.out.println(myName+": inizio aggiunta");
				boolean go=ctrl.autorizzazioneAggiunta();
				if(go) {
					System.out.println(myName+": richiedo aggiunta");
					ctrl.inizioAttesaFineAggiunta();
					try {
						theServer.aggiuntaRisorsa(new Risorsa("pippo", null), this);
					} catch (RemoteException e) {
						// qui bisognerebbe gestire il fallimento dell'aggiunta
						System.err.println(myName+": aggiunta fallita");
					}
					System.out.println(myName+": procedo dopo richiesta aggiunta");
				} else {
					System.out.println(myName+": rinuncio a fare aggiunta");
				}
			} else {
				// faccio un prelievo
				System.out.println(myName+": inizio prelievo");
				boolean go=ctrl.autorizzazionePrelievo();
				if(go) {
					System.out.println(myName+": richiedo prelievo");
					ctrl.inizioAttesaFinePrelievo();
					try {
						theServer.prelievoRisorsa(this);
					} catch (RemoteException e) {
						// qui bisognerebbe gestire il fallimento del prelievo
						System.err.println(myName+": prelievo fallito");
					}
					System.out.println(myName+": procedo dopo richiesta prelievo");
				} else {
					System.out.println(myName+": rinuncio a fare prelievo");
				}
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) { }
		}
		try {
			UnicastRemoteObject.unexportObject(this, true);
		} catch (NoSuchObjectException e) {	}
	}
	public static void main(String[] args) throws RemoteException, NotBoundException {
		Registry registro;
		registro = LocateRegistry.getRegistry(args[0],1099);
		ServerInterf theServer = (ServerInterf) registro.lookup("GestoreRisorse");
		ClientImpl c=new ClientImpl(theServer, args[1]);
		c.exec();
	}
}
