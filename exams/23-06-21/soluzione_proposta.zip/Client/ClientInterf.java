import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ClientInterf extends Remote{
	public void comunicaRisorsa(Risorsa r) throws RemoteException;
	public void comunicaAggiunta() throws RemoteException;
}
