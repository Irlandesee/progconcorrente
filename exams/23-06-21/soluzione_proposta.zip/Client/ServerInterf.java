import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ServerInterf extends Remote {
	public void aggiuntaRisorsa(Risorsa r, ClientInterf c) throws RemoteException;
	public void prelievoRisorsa(ClientInterf c) throws RemoteException;
}
