import java.rmi.RemoteException;
import java.util.concurrent.BlockingQueue;

public class Slave extends Thread {
	BlockingQueue<Risorsa> depositoRisorse;
	Risorsa risorsa;
	ClientInterf theClient;
	boolean devoAggiungere;
	public Slave(BlockingQueue<Risorsa> dr, Risorsa r, ClientInterf c) {
		depositoRisorse=dr;
		risorsa=r;
		theClient=c;
		devoAggiungere=true;
	}
	public Slave(BlockingQueue<Risorsa> dr, ClientInterf c) {
		depositoRisorse=dr;
		theClient=c;
		devoAggiungere=false;
	}
	public void run() {
		try {
			if(devoAggiungere) {
				depositoRisorse.put(risorsa);
			} else {
				risorsa=depositoRisorse.take();
			}
		} catch (InterruptedException e) {	}
		System.out.println("Server: risorsa aggiunta: "+depositoRisorse.size()+" risorse disponibili");
		try {
			if(devoAggiungere) {
				theClient.comunicaAggiunta();
				System.out.println("Server: aggiunta risorsa comunicata");
			} else {
				theClient.comunicaRisorsa(risorsa);
				System.out.println("Server: prelievo risorsa comunicato");
			}
		} catch (RemoteException e) {	}

	}

}
