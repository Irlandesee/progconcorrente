import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.*;

public class ServerImpl extends UnicastRemoteObject implements ServerInterf {
	private static final long serialVersionUID = 1L;
	BlockingQueue<Risorsa> depositoRisorse; // NB: BlockingQueue e` thread safe!!!
	final int dimensioneDeposito=10;
	protected ServerImpl() throws RemoteException {
		super();
		depositoRisorse=new ArrayBlockingQueue<Risorsa>(dimensioneDeposito);
	}
	public void aggiuntaRisorsa(Risorsa r, ClientInterf c) throws RemoteException {
		System.out.println("Server: inizio aggiunta risorsa");
		new Slave(depositoRisorse, r, c).start();
	}
	public void prelievoRisorsa(ClientInterf c) throws RemoteException {
		System.out.println("Server: inizio prelievo risorsa");
		new Slave(depositoRisorse, c).start();
	}
	public static void main(String[] args) {
		try {
			ServerImpl obj = new ServerImpl();
			Registry registro = LocateRegistry.createRegistry(1099);
			registro.rebind("GestoreRisorse", obj);
			System.out.println("Server ready");
		} catch (Exception e) {
			System.err.println("Server exception: " + e.toString());
			e.printStackTrace();
		}
	}
}
