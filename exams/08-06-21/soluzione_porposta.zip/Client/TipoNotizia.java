
public enum TipoNotizia {
	Politica, Attualita, Sport, Scienza;
}
