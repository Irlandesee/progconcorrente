import java.io.IOException;
import java.io.ObjectInputStream;

public class ClientSlave extends Thread {
	ObjectInputStream ins;
	Result res;
	ClientSlave(ObjectInputStream in, Result r){
		ins=in;
		res=r;
	}
	public void run() {
		try {
			System.out.println("slave: waiting from server");
			res=(Result)ins.readObject();
			System.out.println("slave: received from server"+res);
			res.setCompleted();
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
}
