import java.net.*;
import java.io.*;
import java.util.concurrent.*;
import java.util.Random;

class ClientThread extends Thread {

	// private static int counter = 0;
	private static int threadcount = 0;
	private int myID;
	BankProxy myBank;
	Result res;

	public static int threadCount() {
		return threadcount;
	}
	public ClientThread(InetAddress addr, int id) {
		System.out.println("Making client " + id);
		myID=id;
		synchronized(ClientThread.class) {
			threadcount++;
		}
		try {
			myBank=new BankProxy(addr);
			this.start();
		} catch (IOException e) {
			System.err.println("Client "+myID+": proxy creation failed");
			synchronized(ClientThread.class) {
				threadcount--;
			}
		}
	}
	public void run() {
		Random rand = new Random();
		System.out.println("Client_"+myID+" running");
		int howMuch=0;
		String opType;
		OperationRequest op=null;
		int times=(rand.nextInt(10))+2;
		try {
			for (int i = 0; i < times; i++) {
				howMuch=new Random().nextInt(1000);
				if(new Random().nextBoolean()) {
					opType="Deposit";
				} else {
					opType="Withdraw";
				}
				res=new Result(myID, howMuch, opType, false);
				op=new OperationRequest(myID, howMuch, opType);
				System.out.println("Client"+myID+"richiedo"+op);
				myBank.executeOperation(res, op);
				do_something();
				System.out.println("Client"+myID+res);
				try {
					Thread.sleep(ThreadLocalRandom.current().nextInt(1, 4));
				} catch (InterruptedException e) {}
			}
			myBank.quit();
		}
		finally {
			synchronized(ClientThread.class) {
				threadcount--;
			}
		}
	}
	private void do_something() {
		boolean finito=false;
		while(!finito) {
			System.out.println("Client"+myID+"doing something");
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) { }
			finito=res.isCompleted();
		}
	}
}
