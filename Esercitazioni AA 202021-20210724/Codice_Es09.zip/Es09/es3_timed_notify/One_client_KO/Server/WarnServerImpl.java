import java.io.*;
import java.util.*;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;
import java.rmi.server.UnicastRemoteObject;

public class WarnServerImpl extends UnicastRemoteObject implements WarnServer {
	WarnServerImpl() throws RemoteException {
	}
	public void WarnAt(int X, WarnClient c) throws RemoteException {
		System.out.println("server riceve richiesta");
		try {
			Thread.sleep(X*1000);
		} catch(InterruptedException e) {
		}
		c.notifyWarn();
	}
	public static void main(String[] Args) throws RemoteException {
		WarnServer s = new WarnServerImpl();
		Registry reg = LocateRegistry.createRegistry(1099);
		reg.rebind("WARNAT", s);
	}

}
