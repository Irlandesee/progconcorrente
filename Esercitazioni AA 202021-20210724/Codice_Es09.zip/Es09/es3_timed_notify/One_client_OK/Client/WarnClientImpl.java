import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class WarnClientImpl extends UnicastRemoteObject implements WarnClient{
	private static final long serialVersionUID = 1L;
	protected WarnClientImpl() throws RemoteException {
		super();
	}
	public void notifyMe() throws RemoteException {
		System.out.println("warning received from server!");
	}
	public static void main(String[] args) throws RemoteException {
		Registry reg=null;
		try {
			reg=LocateRegistry.getRegistry(1099);
		} catch (RemoteException e) {
			System.err.println("could not find the registry");
			System.exit(0);
		}
		WarnServer laSveglia=null;
		try {
			laSveglia = (WarnServer) reg.lookup("WarnAt");
		} catch (RemoteException | NotBoundException e) {
			System.err.println("could not find the service");
			System.exit(0);
		}  // MCDimpl euclMCD= new MCDimpl();
		WarnClient c = new WarnClientImpl();
		laSveglia.warnAt(6, c);
		for(int i=0; i<10; i++) {
			System.out.println("doing something");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) { }
		}
		System.out.println("Terminating");
		UnicastRemoteObject.unexportObject(c, true);
	}
}
