import java.rmi.RemoteException;

public class WarningThread extends Thread {
	int delay;
	WarnClient client;
	WarningThread(int X, WarnClient c){
		client=c;
		delay=X;
	}
	public void run() {
		try {
			Thread.sleep(delay*1000);
		} catch(InterruptedException e) {
		}
		try {
			client.notifyWarn();
		} catch (RemoteException e) {
			System.err.println("warning thread: clint warning failed.");
		}
	}

}
