import java.io.*;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class MultiClient {
	static final int MAX_THREADS = 3;
	static final int CLIENT_THREADS_TOT = 8;
	void exec() {
		Registry reg;
		try {
			reg = LocateRegistry.getRegistry();
			WarnServer stub = (WarnServer) reg.lookup("WARNAT");
			int i=0;
			while (i<CLIENT_THREADS_TOT) {
				if (WarnClientImpl.threadCount() < MAX_THREADS){
					new WarnClientImpl(i++, stub);
				} else {
					try { Thread.sleep(200); } catch(InterruptedException ei) {}
				}
			}
		} catch (RemoteException | NotBoundException e) {
			System.err.println("connecting to server failed");
		}		
	}
	public static void main(String[] args) throws IOException, InterruptedException {
		MultiClient mc=new MultiClient();
		mc.exec();
	}
}
