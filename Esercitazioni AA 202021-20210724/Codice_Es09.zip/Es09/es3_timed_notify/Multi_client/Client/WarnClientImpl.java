import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
import java.rmi.NoSuchObjectException;

public class WarnClientImpl extends Thread implements WarnClient {
	boolean waitingWarning=true;
	WarnServer theServer=null;
	int myId;
	static int tCount=0;
	WarnClientImpl(int i, WarnServer s){
		synchronized(WarnClientImpl.class) {
			tCount++;
		}
		myId=i;
		theServer=s;
		this.start();
	}
	public static int threadCount() {
		return tCount;
	}
	public void notifyWarn() throws RemoteException {
		Date now = new Date();
		System.out.println("client_"+myId+" riceve notifica @"+ now);
		waitingWarning=false;
	}
	public void run() {
		Random rnd=new Random();
		WarnClient remotCli;
		int secToWait=2+rnd.nextInt(10);
		waitingWarning=true;
		try {
			remotCli = (WarnClient) UnicastRemoteObject.exportObject(this, 2033);
			Date now=new Date();
			System.out.println("client_"+myId+" manda richiesta per attesa di "+secToWait+" sec. @"+ now);
			theServer.WarnAt(secToWait, remotCli);
		} catch (RemoteException e1) {
			System.err.println("remote exception!");
			waitingWarning=false;  // altrimenti il loop successivo non finisce piu`
		}
		while(waitingWarning) {
			try{
				System.out.println("client "+myId+" doing something");
				Thread.sleep(500);
			} catch(InterruptedException e){}			
		}
		synchronized(WarnClientImpl.class) {
			tCount--;
		}
		try {
			UnicastRemoteObject.unexportObject(this, true);
		} catch (NoSuchObjectException e) {	e.printStackTrace(); }
		System.out.println("client_"+myId+" termina");
	}
}

