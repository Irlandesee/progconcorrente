
public interface MCD {
	public int mcd(int n, int m);
}
