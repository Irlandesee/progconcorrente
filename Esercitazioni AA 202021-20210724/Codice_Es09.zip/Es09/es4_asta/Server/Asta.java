public class Asta {
  private Offerta offertaCorrente;
  private int baseAsta;
  private double rialzo_min;
  Asta(int ba, double rialzmin){
    this.offertaCorrente=new Offerta(ba, "nessuno", TipoEsito.Proposta);
    this.baseAsta=ba;
    this.rialzo_min=rialzmin;
  }
  public synchronized Offerta leggi_offerta() {
    return offertaCorrente;
  }
  public synchronized boolean ricezione_offerta(Offerta o){
    int newOffer = o.getAmount();
    if(newOffer >= offertaCorrente.getAmount()*(1+rialzo_min) && newOffer >= baseAsta){
      offertaCorrente=o;
      return(true);
    } else{
      return(false);
    }
  }
}

