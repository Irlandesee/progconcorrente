
public enum TipoEsito {
	Accettata, Aggiudicata, Respinta, Proposta;
}
