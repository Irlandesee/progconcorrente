import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.LinkedList;
import java.util.List;

public class AstaServerImpl extends UnicastRemoteObject implements AstaServer {
	private static final long serialVersionUID = 1L;
	private Asta lAsta;
	private List<AstaClient> clientList;
	public AstaServerImpl() throws RemoteException {
		super();
		this.clientList=new LinkedList<AstaClient>();
		lAsta=new Asta(100, 0.06);
	}
	public synchronized void addObserver(AstaClient c) throws RemoteException {
		clientList.add(c);
		System.out.println("Server: added observer");
		c.notificaNuovaOfferta(lAsta.leggi_offerta());
	}
	public synchronized void removeObserver(AstaClient c) throws RemoteException {
		clientList.remove(c);
		System.out.println("Server: removed observer "+c.getName());
		if(clientList.size()==1){
			Offerta offCorr=lAsta.leggi_offerta();
			Offerta no=new Offerta(offCorr.getAmount(), offCorr.getWho(), TipoEsito.Aggiudicata);
			for(AstaClient cl: clientList) {
				cl.notificaNuovaOfferta(no);
			}
			System.out.println("Server: asta finita, si chiude! ");
			try {
				Thread.sleep(300); // diamo il tempo ai client di capire che l'asta e` finita e chiudere ordinatamente
			} catch (InterruptedException e) {	e.printStackTrace();} 
			UnicastRemoteObject.unexportObject(this, true);
		}
	}
	public synchronized void propostaOfferta(Offerta o, AstaClient offeringClient) throws RemoteException {
		System.out.println("Server: ricevuta offerta da "+o.getWho()+" per "+o.getAmount()+" soldi");
		//   System.out.println("Server: ricevuta offerta da "+offeringClient.getName());
		Boolean esito = lAsta.ricezione_offerta(o);
		System.out.println("Server: offerta "+(esito?"":"non ")+"accettata");
		Offerta no=new Offerta(o.getAmount(), o.getWho(), 
				esito?TipoEsito.Accettata:TipoEsito.Respinta);
		for(AstaClient c: clientList) {
			//			System.out.println("Server: notifico "+c.getName());
			c.notificaNuovaOfferta(no);
		}
	}
	public synchronized Offerta letturaOffertaCorrente(AstaClient c) throws RemoteException {
		return lAsta.leggi_offerta();
	}

	public static void main(String args[]) {
		try {
			AstaServerImpl obj = new AstaServerImpl();
			Registry registro = LocateRegistry.createRegistry(1099);
			registro.rebind("ASTA", obj);
			System.err.println("Server ready");
		} catch (Exception e) {
			System.err.println("Server exception: " + e.toString());
			e.printStackTrace();
		}
	}
}
