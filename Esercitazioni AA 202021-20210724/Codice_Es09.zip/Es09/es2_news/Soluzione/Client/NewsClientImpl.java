import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.NotBoundException;
import java.rmi.RemoteException; 

public class NewsClientImpl {
	private CliBuffer theBuf;
	private NewsServer myServ;
	NewsClientImpl(NewsServer serv) {
		myServ=serv;
		theBuf=new CliBuffer();
		try {
			NewsFetcherImpl newsMon=new NewsFetcherImpl(theBuf, myServ);			
			System.out.println("client: fetcher created");
			serv.addObserver(newsMon);
			System.out.println("client: fetcher added to observers");
		} catch (RemoteException e1) { e1.printStackTrace(); }
		while(true){
			try {
				Thread.sleep(550);
			} catch (InterruptedException e) { e.printStackTrace(); }
			if(theBuf.newsIsFresh()){
				String st;
				try {
					st = theBuf.getNews();
					System.out.println("Client read "+st);
				} catch (InterruptedException e) { e.printStackTrace(); }
			} else {
				System.out.println("client: no fresh news");
			}
		}
		//		System.out.println("Finito");
	}
	public static void main(String[] args) throws InterruptedException, RemoteException, NotBoundException {
		Registry registro;
		if(args.length==0) {
			registro = LocateRegistry.getRegistry(1099);
		} else {
			registro = LocateRegistry.getRegistry(args[0],1099);
		}
		NewsServer news = (NewsServer) registro.lookup("NEWS");
		new NewsClientImpl(news);
	}
}

