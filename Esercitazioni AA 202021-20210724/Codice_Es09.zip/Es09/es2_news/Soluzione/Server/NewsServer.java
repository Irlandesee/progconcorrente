
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface NewsServer extends Remote{
	public String readNews() throws RemoteException;
	public void addObserver(NewsFetcher c) throws RemoteException;
}
