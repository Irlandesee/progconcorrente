
public enum EsitoLettura {
	LettoNumero, ErroreIO, LettoSchifezza, LettoEOF
}
