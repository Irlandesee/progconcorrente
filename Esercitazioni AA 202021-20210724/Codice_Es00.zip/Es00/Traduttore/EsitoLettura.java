
public enum EsitoLettura {
	LettoParola, ErroreIO, LettoEOF
}
