import java.io.IOException;
import java.net.*;

public class Server {
	static final int PORT = 8999;
	public static void main(String[] args) throws IOException {
		Bank theBank=new Bank(10);
		ServerSocket s = new ServerSocket(PORT);
		while(true){
			Socket socket=s.accept();
			new BankServerThread(socket, theBank).start();
		}
	}
}
