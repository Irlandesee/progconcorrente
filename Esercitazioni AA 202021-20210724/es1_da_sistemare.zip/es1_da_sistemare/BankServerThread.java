import java.io.*;
import java.net.*;

public class BankServerThread extends Thread{
	private Socket socket;
	Bank bank;
	private ObjectInputStream ins;
	private ObjectOutputStream outs;
	BankServerThread(Socket s, Bank b) throws IOException{
		socket=s;
		bank=b;
		outs = new ObjectOutputStream(socket.getOutputStream());
		ins = new ObjectInputStream(socket.getInputStream());
	}
	public void run() {
		while(true) {
			try {
				OperationRequest op = (OperationRequest) ins.readObject();
				if(op.getRequest().equals("END")){
					break;
				}
				Result res=bank.executeOperation(op);

				outs.writeObject(res);
			} catch (IOException e) {
				System.err.println("Communication problem");
			} catch (ClassNotFoundException e) {
				System.err.println("Class not found");
			} finally {
				try {
					socket.close();
				} catch (IOException e) { }
			}
		}
	}
}
