import java.io.IOException;
import java.net.*;
import java.util.Random;

public class ClientThread extends Thread {
	static int threadcount=0;
	BankProxy myBank;
	int myAccountNum;
	ClientThread(InetAddress addr, int id){
		myAccountNum=id;
		synchronized(ClientThread.class) {
			threadcount++;
		}
		try {
			myBank=new BankProxy(addr);
			this.start();
		} catch (IOException e) {
			System.err.println("Client "+id+": proxy creation failed");
			synchronized(ClientThread.class) {
				threadcount--;
			}
		}
	}
	public static int threadCount() {
		return threadcount;
	}
	public void run() {
		Result r;
		int howMuch=0;
		int times=(new Random().nextInt(10))+2;
		for(int i=0; i<times; i++) {
			howMuch=new Random().nextInt(1000);
			if(new Random().nextBoolean()) {
				r=myBank.executeOperation(new OperationRequest(myAccountNum, howMuch, "Deposit"));
			} else {
				r=myBank.executeOperation(new OperationRequest(myAccountNum, howMuch, "Withdraw"));
			}
			System.out.println(r);
		}
		r=myBank.executeOperation(new OperationRequest(myAccountNum, 2, "Double"));
		System.out.println(r);
		myBank.quit();
		synchronized(ClientThread.class) {
			threadcount--;
		}
	}
}
