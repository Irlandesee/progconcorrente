import java.io.*;
import java.util.Observable;

public class InputEventSource extends Observable implements Runnable {
	public void run() {
		try {
			final InputStreamReader isr = new InputStreamReader(System.in);
			final BufferedReader br = new BufferedReader(isr);
			while(true) {
				System.out.println("Enter Text >");
				final String str = br.readLine();
				setChanged();
				notifyObservers(str);
			}
		}
		catch (IOException e) {}
	}
}