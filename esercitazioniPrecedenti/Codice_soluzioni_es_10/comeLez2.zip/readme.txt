terminal 1:

cd /<path>/es2/src
javac -d . RemoteObserver.java
javac -d . RemoteObserverImpl.java
javac -d . RMIObservableService.java
javac -d . RMIObservableServiceImpl.java
javac -d . WrappedObserver.java
cp RMIObservableService.class ../../Test
mv RemoteObserverImpl.class ../../Test
cp RemoteObserver.class ../../Test

java RMIObservableServiceImpl


terminal 2:

cd /<path>/Test
java RemoteObserverImpl localhost

