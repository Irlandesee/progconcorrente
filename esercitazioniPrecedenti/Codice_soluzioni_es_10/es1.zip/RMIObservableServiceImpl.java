import java.util.*;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.registry.LocateRegistry;
public class RMIObservableServiceImpl implements Observer, RMIObservableService {
	private List<RemoteObserver> listeners = new ArrayList<RemoteObserver>();
	InputEventSource evSrc;
	public RMIObservableServiceImpl() {
		// create an event source - reads from stdin
		evSrc = new InputEventSource();
		evSrc.addObserver(this);
		new Thread(evSrc).start();
	}
	public void addRemoteObserver(RemoteObserver o) throws RemoteException {
		listeners.add(o);
	}
	public static void main(String[] args) {
		try {
			RMIObservableService obj = new RMIObservableServiceImpl();
			RMIObservableService stub = (RMIObservableService) UnicastRemoteObject.exportObject(obj, 3940);
			Registry registry = LocateRegistry.createRegistry(1099);
			registry.rebind("RmiService", stub);
			System.err.println("Server ready");
			//			((RMIObservableServiceImpl)obj).run();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	@Override
	public void update(Observable arg0, Object arg1) {
		String s=(String)arg1;
		System.out.println("letta stringa "+s);
		for(RemoteObserver l: listeners) {
			try {
				l.remoteNotify(this, s);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
}