import java.util.concurrent.ThreadLocalRandom;

public class MainClass {
	public static void main(String[] args) throws InterruptedException {
		int numClienti=12;
		Thread.currentThread().setName("main");
		Negozio negozio=new Negozio();
		Barbiere barb=new Barbiere(negozio);
		barb.start();
		for(int ic=0; ic<numClienti; ic++){
			new Cliente(ic, negozio);
			Thread.sleep(ThreadLocalRandom.current().nextInt(50,120));
		}
	}
}
