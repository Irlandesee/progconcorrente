public class Barbiere extends Thread {
	private Negozio ilMioNegozio;
	public Barbiere(Negozio n){
		Thread.currentThread().setName("Barber");
		ilMioNegozio=n;
	}
	public void run(){
		while(true){
			ilMioNegozio.attesaCliente();
			while(ilMioNegozio.clientiInAttesa()){
				String clienteDaServire=ilMioNegozio.primoClienteDaServire();
				ilMioNegozio.servoCliente(clienteDaServire);
				try {
					sleep(100); // taglio
				} catch (InterruptedException e) { }
				ilMioNegozio.fineTaglio(clienteDaServire);
			}
		}
	}
}
