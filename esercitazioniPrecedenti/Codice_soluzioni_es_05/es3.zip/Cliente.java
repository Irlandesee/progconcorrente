
public class Cliente extends Thread{
	private String myId;
	private Negozio barberia;
	public Cliente(int id, Negozio n){
		myId="Cliente#"+id;
		Thread.currentThread().setName(myId);
		barberia=n;
		start();
	}

	public void run(){
		if(barberia.entra(myId)){
			barberia.attesaTurno(myId);	
			barberia.attesaFineTaglio(myId);
		}
	}
}
