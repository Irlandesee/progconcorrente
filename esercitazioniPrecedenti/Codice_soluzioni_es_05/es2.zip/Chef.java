
public class Chef extends Thread {
	private Kitchen theKitchen;
	public Chef(Kitchen k) {
		this.theKitchen = k;
		start();
	}

	public void run() {
		Thread.currentThread().setName("The Chef");
		while (true) {
			try {
				String orderToServe=theKitchen.nextOrder();
				if(interrupted()){
					break;  // quando riceve interrupt esce dal cilco e termina
				}
				System.out.println("TheChef - I'm starting to prepare order "+orderToServe);
				theKitchen.prepare(orderToServe);
			} catch (InterruptedException e) {
				break;  // quando riceve interrupt esce dal cilco e termina
			}
		}	
		System.out.println("The kitchen closes down");
	}
}
