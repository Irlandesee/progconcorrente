import java.util.concurrent.ThreadLocalRandom;

public class Musician extends Thread {
	private BeerAwaiters thirstyList;
	private String myName;
	private ServedBeers freeBeers;
	public Musician(int n, BeerAwaiters ba, ServedBeers sb) {
		this.myName = "Musician_"+n;
		this.thirstyList = ba;
		this.freeBeers = sb;
	}
	public void run() {
		int numSessions = (int) (Math.random() * 10);
		boolean freeBeerServed;
		for (int i = 0; i < numSessions; ++i) {
			try {
				int num = (int) (Math.random() * 10);
				for (int j = 0; j < num; j++) {
					System.out.print(myName + " ");
					Thread.sleep(100);
				}
				System.out.println("\n"+ myName + ": I need a beer!");
				thirstyList.add(myName);
				Thread.sleep(10+ThreadLocalRandom.current().nextInt(0, 50));
				freeBeerServed=freeBeers.fetch(myName);
				if(freeBeerServed){
					System.out.println("\n"+ myName + ": I drink a free beer!");					
				} else {
					System.out.println("\n"+ myName + ": no beer :-(");					
				}
			} catch (InterruptedException e) {
			}
		}
		System.out.println(myName + ": I go home!");
	}
}
