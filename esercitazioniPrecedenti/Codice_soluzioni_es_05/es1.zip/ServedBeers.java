import java.util.*;

public class ServedBeers {
	private List<String> servedBeers;
	ServedBeers() {
		servedBeers=new ArrayList<String>();
	}
	public synchronized void serve(String s){
		servedBeers.add(s);
		notifyAll();
	}
	public synchronized boolean fetch(String s){
		long timeToExit=System.currentTimeMillis()+600;
		while(!servedBeers.contains(s)){
			try {
				wait(timeToExit-System.currentTimeMillis());
			} catch (InterruptedException e) {	}
			if(System.currentTimeMillis()>=timeToExit && !servedBeers.contains(s))
				return false;
		}
		if(servedBeers.contains(s)){
			servedBeers.remove(s);
			return true;
		} else return false;
	}
}
