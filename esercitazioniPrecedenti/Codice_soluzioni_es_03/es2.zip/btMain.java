
public class btMain {
	public static void printBT(BinTree bt){
		if(bt!=null){
			if(bt.getLeft()!=null){
				System.out.print("["); printBT(bt.getLeft()); System.out.print("]");
			}
			System.out.print(" " + bt.getValue() + " ");
			if(bt.getRight()!=null){
				System.out.print("["); printBT(bt.getRight()); System.out.print("]");
			}
		}
	}
	// seqSearch implementa la ricerca sequenziale
	public static BinTree seqSearch(BinTree bt, int vx){
		//		System.out.println("Start of search "+vx);
		if(bt==null){
			return bt;
		}
		if(bt.getValue()==vx){
			return bt;
		}
		//		System.out.println("Start searching left "+vx);
		BinTree res=seqSearch(bt.getLeft(), vx);
		if(res!=null){
			if(res.getValue()==vx){
				return res;
			}
		}
		//		System.out.println("Start searching right "+vx);
		res=seqSearch(bt.getRight(), vx);
		if(res!=null){
			if(res.getValue()==vx){
				return res;
			}
		}
		//		System.out.println("End search (not found) "+vx);
		return (BinTree)null;
	}
	public static void main(String args[]) throws InterruptedException{
		BinTree bt1 = new BinTree(5, null, null);
		bt1.addLeft(new BinTree(3, null, null));
		bt1.addRight(new BinTree(11, null, null));
		BinTree bt2 = new BinTree(15, null, null);
		bt2.addLeft(new BinTree(13, null, null));
		bt2.addRight(new BinTree(19, null, null));
		BinTree bt3=new BinTree(12, bt1, bt2);
		printBT(bt3); System.out.println();
		int vx=13;
		BinTree res=seqSearch(bt3, vx);
		if(res==null){
			System.out.println("Not found "+vx);
		} else {
			System.out.println("Found "+vx);
		}
		vx=6;
		res=seqSearch(bt3, vx);
		if(res==null){
			System.out.println("Not found "+vx);
		} else {
			System.out.println("Found "+vx);
		}
		System.out.println("================================");
		Result resObj=new Result(7);
		vx=15;
		Thread mySearcher = new ParallelSearchThread(bt3, vx, resObj);
		System.out.println("Main: launching thread "+mySearcher.getName());
		mySearcher.start();
		while(!resObj.isCompleted()){
			System.out.println("Main dorme");
			Thread.sleep(100);
		}
		if(resObj.isSuccess()){
			System.out.println("Main: Found "+vx);
		} else {
			System.out.println("Main: Not found "+vx);			
		}
	}
}
