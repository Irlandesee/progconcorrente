
public class BinTree {
	private int value;
	private BinTree left=null;
	private BinTree right=null;
	public BinTree(int v, BinTree l, BinTree r){
		this.value=v;
		this.left=l;
		this.right=r;
	}
	public BinTree getLeft(){
		return this.left;
	}
	public BinTree getRight(){
		return this.right;
	}
	public int getValue(){
		return this.value;
	}
	public void addLeft(BinTree bt){
		this.left=bt;
	}
	public void addRight(BinTree bt){
		this.right=bt;
	}
}
