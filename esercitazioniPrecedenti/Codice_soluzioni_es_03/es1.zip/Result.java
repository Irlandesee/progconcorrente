
public class Result {
	private int expectedSums;
	private int completedSums=0;
	public Result(int exp) {
		this.expectedSums=exp;
		this.completedSums=0;
	}
	// incSums viene chiamato da ogni tjhread che ha finito il suo compito
	public synchronized void incSums(){
		this.completedSums++;
	}
	// isCompleted viene chiamato dal main per sapere se i thread hanno TUTTI
	// completato il loro compito
	public boolean isCompleted(){
		return (completedSums==expectedSums);
	}
}
