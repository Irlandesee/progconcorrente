import java.util.concurrent.*;

public class ParMatSum {
	private static int matrix[][]=
		{
		{ 1, 2, 3, 4, 5} ,
		{ 2, 2, 2, 2, 2 } ,
		{ 3, 3, 3, 3, 3 } ,
		{ 4, 4, 4, 4, 3 } ,
		{ 5, 5, 5, 5, 5 } } ;
	private static int results[];
	private static class Summer extends Thread {
		int row;  // indice della riga su cui lavorare
		Result resRef;  // riferimento all'oggetto in cui segnalare che si e` finito
		Summer(int row, Result rr) {
			this.row=row;
			this.resRef=rr;
		}
		public void run() {
			int columns=matrix[row].length;  // numero di colonne
			int sum=0;
			for(int i=0; i<columns; i++) {
//				System.out.println("thread "+this.getName()+" deal with "+matrix[row][i]);
				sum += matrix[row][i];
			}
			results[row]=sum;
			System.out.println("thread "+this.getName()+" increments sums ");
			resRef.incSums();
			System.out.println("Result for row "+row+" is: " + sum);
		}
	}
	public static void main(String args[]) throws InterruptedException {
		final int rows=matrix.length;  // number of rows
		final int cols=matrix[0].length;  // number of columns
		results=new int[rows];
		Result res=new Result(rows);
		for(int i=0; i<rows; i++){
			System.out.print("[");
			for(int j=0; j<cols; j++){
				System.out.print(matrix[i][j]+" ");
			}
			System.out.println("]");
		}
		for(int i=0; i<rows; i++) {
			new Summer(i, res).start();
		}
		while(!res.isCompleted()){
			System.out.println("Waiting...");
			Thread.sleep(10);
		}
		int total=0;
		System.out.print("[");
		for(int i=0; i<rows; i++){
			total+=results[i];
			System.out.print(results[i]+" ");
		}
		System.out.println("]");
		System.out.print("total = "+total);
	}
}