
public interface SegmentInterface {
	public boolean set(Point p1, Point p2);
	public Point simmetric(Point p);
}
