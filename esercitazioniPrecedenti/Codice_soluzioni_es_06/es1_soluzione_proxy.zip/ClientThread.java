import java.net.*;
import java.util.concurrent.*;

class ClientThread extends Thread {
	private static int threadcount = 0;
	private int myID;
	SegmentProxyServer sps;
	public static int threadCount() {
		return threadcount;
	}
	public ClientThread(InetAddress addr, int id) {
		System.out.println("Making client " + id);
		myID=id;
		threadcount++;
		sps = new SegmentProxyServer(addr, 8080);
		this.start();
	}
	public void run() {
		for (int i = 0; i < 5; i++) {
			boolean segmentOK=false;
			while(!segmentOK){
				System.out.println("Client_"+myID+": asking for segment creation");
				Point p1=new Point(100*Math.random(), 100*Math.random());
				System.out.println("Client_"+myID+" point 1: (" + p1.getX() + " " + p1.getY() + ")");
				Point p2=new Point(100*Math.random(), 100*Math.random());
				System.out.println("Client_"+myID+" point 2: (" + p2.getX() + " " + p2.getY() + ")");
				segmentOK=sps.set(p1, p2);
				try { Thread.sleep(ThreadLocalRandom.current().nextInt(1, 4));
				} catch (InterruptedException e) {	}
			}
			System.out.println("Client_"+myID+": segment created");
			try { Thread.sleep(ThreadLocalRandom.current().nextInt(1, 4));
			} catch (InterruptedException e) {	}
			Point px=new Point(100*Math.random(), 100*Math.random());
			System.out.println("Client_"+myID+" given point: (" + px.getX() + " " + px.getY() + ")");
			Point ps = sps.simmetric(px);
			System.out.println("Client_"+myID+" simmetric point: (" + ps.getX() + " " + ps.getY() + ")");
		}
		sps.quit();
		threadcount--; // Ending this thread
	}
}

