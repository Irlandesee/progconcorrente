import java.io.Serializable;

public class Operation implements Serializable{
	private static final long SerialVersionUID = 10l; 
	int CCnumber;
	int amount;
	String type;
	Operation(int cc, int val, String what){
		CCnumber=cc;
		amount=val;
		type=what;
	}
	public int getCCnumber() {
		return CCnumber;
	}
	public int getAmount() {
		return amount;
	}
	public String getType() {
		return type;
	}
}
