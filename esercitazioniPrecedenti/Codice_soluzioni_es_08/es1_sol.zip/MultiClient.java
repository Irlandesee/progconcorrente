import java.net.*;
import java.io.*;

public class MultiClient {
	static final int MAX_THREADS = 5;
	static final int CLIENT_THREADS_TOT = 3;
	public static void main(String[] args) throws IOException, InterruptedException {
		InetAddress addr = InetAddress.getByName(null);
		int i=0;
		while (i<CLIENT_THREADS_TOT) {
			if (ClientThread.threadCount() < MAX_THREADS){
				new ClientThread(addr, i);
				i++;
			} else {
				Thread.sleep(200);
			}
		}
	}
}
