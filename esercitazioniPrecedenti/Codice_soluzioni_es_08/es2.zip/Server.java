import java.net.*;
import java.io.*;

public class Server {

	static final int PORT = 8999;
	public static void main(String[] args) throws IOException {
		ServerSocket s = new ServerSocket(PORT);
		Bank theBank=new Bank();
		System.out.println("Server Started");
		try {
			while (true) {
				Socket socket = s.accept();
				System.out.println("Server accepts connection");
				new BankServerThread(socket, theBank);
			}
		} finally {
			s.close();
		}
	}

}
