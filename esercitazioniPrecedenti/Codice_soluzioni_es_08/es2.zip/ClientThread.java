import java.net.*;
import java.io.*;
import java.util.concurrent.*;
import java.util.Random;

class ClientThread extends Thread {
	private Socket socket;
	private ObjectInputStream ins;
	private ObjectOutputStream outs;
	private static int threadcount = 0;
	private int myID;
	Result opRes;
	Operation[] toDo;
	boolean operationCompleted=false;

	public static int threadCount() {
		return threadcount;
	}
	public ClientThread(InetAddress addr, int id) {
		Random rand = new Random();
		System.out.println("Making client " + id);
		myID=id;
		threadcount++;
		final int numOp=3;
		toDo=new Operation[numOp];
		toDo[0]=new Operation(myID, rand.nextInt(50), "Deposit");
		toDo[1]=new Operation(myID, rand.nextInt(50), "Withdraw");
		toDo[2]=new Operation(myID, rand.nextInt(50), "Deposit");
		try {
			socket = new Socket(addr, Server.PORT);
		} catch (IOException e){System.err.println("Socket failed");}
		try {
			outs = new ObjectOutputStream(socket.getOutputStream());
			ins = new ObjectInputStream(socket.getInputStream());
			start();
		} catch (IOException e) {
			try {
				System.out.println("Client_"+myID+" stream creation KO");
				threadcount--;
				socket.close();
			} catch (IOException e2) {
				System.err.println("Socket not closed");
			}
		}
	}
	public void setCompletion() {
		operationCompleted=true;
	}
	public void setResult(Result r) {
		opRes=r;
	}
	private void printRes(Result res) {
		if(res.isSuccessful()) {
			System.out.println("Client_"+myID+" operation succeeded; total is "+res.getAmount());			
		} else {
			System.out.println("Client_"+myID+" operation failed");
		}
	}
	// method simulating some activity
	private void doSometing() throws InterruptedException {
		while(true) {
			System.out.println("client working");
			Thread.sleep(ThreadLocalRandom.current().nextInt(100, 2000));
			if(operationCompleted)
				break;
		}
	}
	public void run() {
		Result res;

		System.out.println("Client_"+myID+" running");
		try {
			for (int i = 0; i < 3; i++) {
				operationCompleted=false;
				outs.writeObject(toDo[i]);
				ClientSlave messageListener=new ClientSlave(ins, this);
				messageListener.start();
				doSometing();
				printRes(opRes);
			}
			outs.writeObject(new Operation(-1, 0, "END"));
		} catch (IOException e) {
			System.err.println("IO Exception");
		} catch (InterruptedException e) { e.printStackTrace();
		} finally { // Always close it:
			try { 
				socket.close();
			} catch (IOException e) {
				System.err.println("Socket not closed");
			}
			threadcount--; // Ending this thread
		}
	}
}
