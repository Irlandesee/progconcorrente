import java.io.IOException;
import java.io.ObjectInputStream;

public class ClientSlave extends Thread{
	ObjectInputStream ins;
	ClientThread myBoss;

	ClientSlave(ObjectInputStream in, ClientThread ct){
		ins=in;
		myBoss=ct;
	}
	public void run() {
		try {
			Result r=(Result) ins.readObject();
			myBoss.setResult(r);
			myBoss.setCompletion();
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
}
