
public class Client {

	public void start(Bank b) {
		Result r;
		r=b.executeOperation(new Operation(1, 55, "Deposit"));
		if(r.isSuccessful()) {
			System.out.println("operation succeeded; total is "+r.getAmount());			
		} else {
			System.out.println("operation failed");
		}
		r=b.executeOperation(new Operation(1, 82, "Withdraw"));
		if(r.isSuccessful()) {
			System.out.println("operation succeeded; total is "+r.getAmount());			
		} else {
			System.out.println("operation failed");
		}
		r=b.executeOperation(new Operation(1, 22, "Withdraw"));
		if(r.isSuccessful()) {
			System.out.println("operation succeeded; total is "+r.getAmount());			
		} else {
			System.out.println("operation failed");
		}
	}
	public static void main(String[] args) {
		Bank myBank = new Bank();
		Client c=new Client();
		c.start(myBank);
	}

}
