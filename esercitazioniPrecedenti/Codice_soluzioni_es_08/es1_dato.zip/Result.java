
public class Result {
	int CCnumber;
	int amount;
	boolean successful;
	Result(int cc, int val, boolean ok){
		CCnumber=cc;
		amount=val;
		successful=ok;
	}
	public int getCCnumber() {
		return CCnumber;
	}
	public int getAmount() {
		return amount;
	}
	public boolean isSuccessful() {
		return successful;
	}
}
