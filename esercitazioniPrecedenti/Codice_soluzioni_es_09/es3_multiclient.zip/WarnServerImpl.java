import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class WarnServerImpl extends UnicastRemoteObject implements WarnServer {
	private static final long serialVersionUID = 1L;
	WarnServerImpl() throws RemoteException {
	}
	public void WarnAt(int X, WarnClient c) throws RemoteException {
		System.out.println("server riceve richiesta da "+c+" per "+X+" sec.");
		try {
			Thread.sleep(X*1000);
		} catch(InterruptedException e) {
		}
		c.notifyWarn();
	}
	public static void main(String[] Args) throws RemoteException {
		WarnServer s = new WarnServerImpl();
		Registry reg = LocateRegistry.createRegistry(1099);
		reg.rebind("WARNAT", s);
	}

}
