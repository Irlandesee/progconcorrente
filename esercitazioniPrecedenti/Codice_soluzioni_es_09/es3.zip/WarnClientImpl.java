import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.NotBoundException;

public class WarnClientImpl implements WarnClient {
	boolean waitingWarning=false;
	public void notifyWarn() throws RemoteException {
		System.out.println("client riceve notifica");
		waitingWarning=false;
	}
	private void exec(WarnClientImpl c) throws RemoteException {
		WarnServer stub = null;
		WarnClient remotCli = (WarnClient) UnicastRemoteObject.exportObject(c, 2033);
		Registry reg = LocateRegistry.getRegistry();
		try {
			stub = (WarnServer) reg.lookup("WARNAT");
		} catch (RemoteException | NotBoundException e1) {	}
		stub.WarnAt(3, remotCli);
		while(waitingWarning) {
			try{
				Thread.sleep(500);
			} catch(InterruptedException e){}			
		}
		UnicastRemoteObject.unexportObject(c, true);		
	}
	public static void main(String[] Args) throws RemoteException, NotBoundException {
		WarnClientImpl warnCli = new WarnClientImpl();
		warnCli.exec(warnCli);
		System.out.println("client termina");
	}
}

