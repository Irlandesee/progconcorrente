
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface AstaServer extends Remote{
  public void propostaOfferta(Offerta o, AstaClient offeringClient) throws RemoteException;
  public Offerta letturaOffertaCorrente(AstaClient c) throws RemoteException;
  public void addObserver(AstaClient c) throws RemoteException;
  public void removeObserver(AstaClient c) throws RemoteException;
}
