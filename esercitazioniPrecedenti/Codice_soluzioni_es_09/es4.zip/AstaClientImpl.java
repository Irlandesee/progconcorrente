import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.NotBoundException;
import java.rmi.RemoteException; 
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.ThreadLocalRandom;

public class AstaClientImpl extends UnicastRemoteObject implements AstaClient{
	private static final long serialVersionUID = 1L;
	private int maxTries = 3+(int)(Math.random()*4);
	int numTries=0;
	private final double myIncrease=1.1;
	private String myName;
	private AstaServer myServer;
	private Offerta OffCorrente=null;

	AstaClientImpl(String n, AstaServer serv) throws RemoteException {
		super();
		this.myName=n;
		this.myServer=serv;
		this.numTries=0;
	}
	private void uscita() throws RemoteException {
		myServer.removeObserver(this);
		UnicastRemoteObject.unexportObject(this, true);
	}
	private void exec() throws RemoteException{
		while(true){
			if(OffCorrente!=null) {
				int tempoPerPensare=ThreadLocalRandom.current().nextInt(100, 300);
				try {
					Thread.sleep(tempoPerPensare);
				} catch (InterruptedException e) {}
				TipoEsito esito=OffCorrente.getEsito();
				int am=OffCorrente.getAmount();
				String chi=OffCorrente.getWho();
				if(esito==TipoEsito.Aggiudicata) {
					if(chi.equals(myName)) {
						System.out.println(myName+": ho vinto!");
					} else {
						System.out.println(myName+": ho perso!");
					}
					break;
				} else {
					if(numTries<maxTries) {
						if(!chi.equals(myName)) {
							numTries++;
							System.out.println(myName+" offering "+(int) (am*myIncrease));
							myServer.propostaOfferta(new Offerta((int) (am*myIncrease), myName, TipoEsito.Proposta), this);
						}
					} else { // ho finito i tentativi
						if(!chi.equals(myName)) {
							System.out.println(myName+" lascio! ");
							break;
						}
					}
				}

			}
		}
		uscita();
	}
	public void notificaNuovaOfferta(Offerta o) throws RemoteException {
		System.out.println(myName+" ricevuta notifica di offerta "+o);
		OffCorrente=o;
	}
	public String getName() throws RemoteException {
		return this.myName;
	}
	public static void main(String[] args) throws RemoteException, NotBoundException {
		Registry registro = LocateRegistry.getRegistry(args[0],1099);
		AstaServer server = (AstaServer) registro.lookup("ASTA");
		AstaClientImpl me = new AstaClientImpl(args[1], server);
		server.addObserver(me);
		me.exec();
	}
}


