public class Table {
	private int aChiTocca;
	public Table() {
		this.aChiTocca=0;
	}
	public synchronized void aspettoTurno(int chi){
		while(aChiTocca!=chi){
			try {
				wait();
			} catch (InterruptedException e) { e.printStackTrace(); }
		}
	}
	public synchronized void finito() {
		aChiTocca=1-aChiTocca;
		notifyAll();
	}
}



