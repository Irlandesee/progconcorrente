
public class Pong extends Thread {
	int myId;
	Table table;
	public Pong(int id, Table t){
		this.myId=id;
		this.table=t;
	}
	public void run(){
		for(;;){
			table.aspettoTurno(myId);
			System.out.println("Pong");
			table.finito();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) { e.printStackTrace(); }
		}
	}
}