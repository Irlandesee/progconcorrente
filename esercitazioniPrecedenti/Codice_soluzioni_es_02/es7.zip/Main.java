
public class Main {
	public static void main(String[] args) {
		Table tab=new Table();
		new Pong(0, tab).start();
		new Ping(1, tab).start();
	}
}
