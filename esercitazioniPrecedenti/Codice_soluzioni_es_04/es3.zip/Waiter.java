
public class Waiter {
  public synchronized void takeTwo(Chopstick i, Chopstick j)
           throws InterruptedException {
     while(!(i.isAvailable() && j.isAvailable())) {
       wait () ;
     }
     i.take();
     j.take();
  }
  public synchronized void leaveTwo(Chopstick i, Chopstick j) {
     i.leave();
     j.leave();
     notifyAll();
  }
}

