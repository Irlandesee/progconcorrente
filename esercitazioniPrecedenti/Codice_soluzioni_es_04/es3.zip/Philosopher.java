public class Philosopher extends Thread {
	private Chopstick right, left;
	private String name ;
	private Waiter myWaiter;
	public Philosopher(String id, Waiter w,
			Chopstick left, Chopstick right) {
		this.name=id;
		this.left=left;
		this.right=right;
		this.myWaiter=w;
	}

	public void run() {
		while(true) {
			try {
				Thread.sleep(30);
				myWaiter.takeTwo(left, right);
				System.out.println("Phil "+ name + " eating") ;
				Thread.sleep(40);
				myWaiter.leaveTwo(left, right);
			} catch (InterruptedException e) {return ; }
		}
	}
}

