import java.util.concurrent.ThreadLocalRandom;

public class Philosopher extends Thread {
	private Pool pool;
	private String name ;
	public Philosopher(String id, Pool p) {
		this.name=id;
		this.pool=p;
	}
	public void run() {
		int c1, c2;
		while(true) {
			try {
				System.out.println("Phil "+ name + " thinking") ;
				Thread.sleep(ThreadLocalRandom.current().nextInt(400, 500));
				System.out.println("Phil "+ name + " hungry") ;
				while ((c1=pool.get_one_of_many())== -1){
					Thread.sleep(ThreadLocalRandom.current().nextInt(10,15));					
				}
				System.out.println("Phil "+ name + " picked up first chopstick");
				while ((c2=pool.get_one())== -1){
					Thread.sleep(10*ThreadLocalRandom.current().nextInt(10, 15));					
				}
				System.out.println("Phil "+ name + " picked up the second chopstick and is now eating") ;
				Thread.sleep(ThreadLocalRandom.current().nextInt(100, 200));
				pool.free(c2);
				pool.free(c1);
				System.out.println ("Phil "+ name + " freed resources ");
			} catch (InterruptedException e) {return ; }
		}
	}
}
