import java.util.concurrent.ThreadLocalRandom;

public class Philosopher extends Thread {
	private Pool pool;
	private String name ;
	public Philosopher(String id, Pool p) {
		this.name=id;
		this.pool=p;
	}
	public void run() {
		int c1, c2;
		while(true) {
			try {
				System.out.println("Phil "+ name + " thinking") ;
				Thread.sleep(ThreadLocalRandom.current().nextInt(400, 500));
				System.out.println("Phil "+ name + " hungry");
				c1=pool.get_one_of_many();
				System.out.println("Phil "+ name + " picked up first chopstick "+c1);
				c2=pool.get_one();
				System.out.println("Phil "+ name + " picked up the second chopstick "+c2+" and is now eating") ;
				Thread.sleep(ThreadLocalRandom.current().nextInt(100, 200));
				System.out.println("Phil "+ name + " releases chopstick "+c1+" and "+c2) ;
				pool.free(c2);
				pool.free(c1);
			} catch (InterruptedException e) { }
		}
	}
}
